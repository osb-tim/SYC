create trigger `delete`
  after DELETE
  on user
  for each row
  DELETE FROM personaldata WHERE uid=old.Id;

