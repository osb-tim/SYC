create trigger `insert`
  after INSERT
  on user
  for each row
  INSERT INTO `personaldata` (uid,phone,nickName,sign) VALUES (new.id,new.loginname,CONCAT('wiki用户',new.id),'这个人很懒，什么都没写哦…………');

